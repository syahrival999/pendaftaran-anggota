<!DOCTYPE html>
<html>
<head>
    <title>Pendaftaran Anggota Baru |Karang Taruna RW 02</title>
    <link rel="stylesheet" href="css/style.css">
   
</head>

<body>
    <header>
        <h3>Pendaftaran Anggota Baru</h3>
        <h1>Karang Taruna Rw 02</h1>
    </header>

    <h4>Menu</h4>
    <nav>
        <ul>
            <li><a href="form-daftar.php">Daftar Baru</a></li>
            <li><a href="list-Anggota.php">Pendaftar</a></li>
        </ul>
    </nav>

    </body>
</html>